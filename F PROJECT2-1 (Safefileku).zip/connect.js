require("./all/global")

const func = require("./all/place")
const readline = require("readline");
const usePairingCode = true
const question = (text) => {
  const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
  });
  return new Promise((resolve) => {
rl.question(text, resolve)
  })
};

function _0x2257(_0x47fc0f, _0x2337ef) {
    var _0x1390e2 = _0xf4de();
    return _0x2257 = function (_0x4e6137, _0x4ca931) {
        _0x4e6137 = _0x4e6137 - (0x1bb2 + -0x250a + 0xa7e);
        var _0x38b095 = _0x1390e2[_0x4e6137];
        return _0x38b095;
    }, _0x2257(_0x47fc0f, _0x2337ef);
}
var _0x420a93 = _0x2257;
function _0xf4de() {
    var _0xa30ee8 = [
        '177OJAqOC',
        'e\x0aPowered\x20',
        'l\x20Dev«-',
        '279zUHvqG',
        '110364eiKCtX',
        '7MRPyUD',
        '8ztoIPH',
        '13716219JOuZFJ',
        '121575xCNYqC',
        'magenta',
        '239830kyoHjh',
        '79852aMNsYG',
        '4589BCbtNB',
        'log',
        'bold',
        '24PgfwpN',
        '117386iAiyND',
        '4464232VisaJA',
        'base-simpl',
        'By\x20-»\x20Fade'
    ];
    _0xf4de = function () {
        return _0xa30ee8;
    };
    return _0xf4de();
}
(function (_0x5c59ac, _0x43c532) {
    var _0x569381 = _0x2257, _0x3c4169 = _0x5c59ac();
    while (!![]) {
        try {
            var _0x5bcecc = -parseInt(_0x569381(0x130)) / (0x2 * -0x9ee + 0xe78 * 0x1 + 0x565) * (parseInt(_0x569381(0x126)) / (-0x1369 + 0xeb9 + 0x4b2)) + -parseInt(_0x569381(0x12a)) / (0x505 * -0x1 + 0xa2 * -0x3 + 0x6ee * 0x1) * (parseInt(_0x569381(0x135)) / (0x1889 + -0x3 * 0x6b + 0x2 * -0xba2)) + -parseInt(_0x569381(0x132)) / (-0x646 + -0x5c3 * 0x5 + 0x231a) * (-parseInt(_0x569381(0x139)) / (-0x23f4 + 0x4eb + 0x1f0f)) + -parseInt(_0x569381(0x12f)) / (0x71 * -0x43 + -0x143 * 0x8 + 0x27b2) * (parseInt(_0x569381(0x127)) / (0x25df + 0x3 * -0x711 + -0x10a4)) + parseInt(_0x569381(0x12d)) / (0xbd6 + 0x1 * 0x13fe + -0x1fcb) * (parseInt(_0x569381(0x134)) / (0x1967 + -0xf4c + -0xa11)) + -parseInt(_0x569381(0x131)) / (-0x269f * 0x1 + 0x1b7e + -0x104 * -0xb) + -parseInt(_0x569381(0x12e)) / (-0x4a * -0x1f + 0x9dc + -0x12c6) * (-parseInt(_0x569381(0x136)) / (0x482 * -0x6 + 0x389 + -0x1d * -0xd0));
            if (_0x5bcecc === _0x43c532)
                break;
            else
                _0x3c4169['push'](_0x3c4169['shift']());
        } catch (_0x55d9cd) {
            _0x3c4169['push'](_0x3c4169['shift']());
        }
    }
}(_0xf4de, -0xa2978 + -0x7aafc + 0x1b84bf), console[_0x420a93(0x137)](chalk[_0x420a93(0x133)][_0x420a93(0x138)](_0x420a93(0x128) + _0x420a93(0x12b) + _0x420a93(0x129) + _0x420a93(0x12c))));

async function startSesi() {
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const { state, saveCreds } = await useMultiFileAuthState(`./session`)
const { version, isLatest } = await fetchLatestBaileysVersion()
const getMessage = async (key) => {
if (store) {
const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
return msg?.message || undefined
}
return {
conversation: "base-v1"
}}

const connectionOptions = {
isLatest,
getMessage,
keepAliveIntervalMs: 30000,
printQRInTerminal: !usePairingCode,
logger: pino({ level: "fatal" }),
auth: state,
browser: ["Ubuntu", "Chrome", "20.0.04"]
}

const Fadel = func.makeWASocket(connectionOptions)
if (usePairingCode && !Fadel.authState.creds.registered) {
const phoneNumber = await question(chalk.cyan.bold('Masukan Nomor Whatsapp Awali dengan 62\nContoh : 628xxxx\n'))
const code = await Fadel.requestPairingCode(phoneNumber.trim())
console.log(`${chalk.cyan.bold('Kode Verifikasi Kamu')} : ${chalk.whiteBright.bold(code.split("").join(" "))}`)
}
store?.bind(Fadel.ev)

Fadel.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
console.log(color(lastDisconnect.error, 'deeppink'))
if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
process.exit()
} else if (reason === DisconnectReason.badSession) {
console.log(color(`Bad Session File, Please Delete Session and Scan Again`))
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionLost) {
console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'))
Fadel.logout()
} else if (reason === DisconnectReason.loggedOut) {
console.log(color(`Device Logged Out, Please Scan Again And Run.`))
Fadel.logout()
} else if (reason === DisconnectReason.restartRequired) {
console.log(color('Restart Required, Restarting...'))
await startSesi()
} else if (reason === DisconnectReason.timedOut) {
console.log(color('Connection TimedOut, Reconnecting...'))
startSesi()
}
} else if (connection === "connecting") {
start(`1`, `Connecting...`)
} else if (connection === "open") {
success(`1`, `Tersambung`)
if (autoJoin) {
Fadel.groupAcceptInvite(codeInvite)
}
}
})

Fadel.ev.on('messages.upsert', async (chatUpdate) => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (m.key && m.key.remoteJid === 'status@broadcast') return Fadel.readMessages([m.key])
if (!Fadel.public && !m.key.fromMe && chatUpdate.type === 'notify') return
if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return
m = func.smsg(Fadel, m, store)
require("./laxz")(Fadel, m, store)
} catch (err) {
console.log(err)
}
})

Fadel.public = true

Fadel.ev.on('creds.update', saveCreds)
return Fadel
}

startSesi()

process.on('uncaughtException', function (err) {
    console.log('Caught exception: ', err)
})