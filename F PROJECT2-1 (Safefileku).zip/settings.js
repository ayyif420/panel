require("./all/module")

global.owner = "6283879471058"
global.namabot = "Cpanel V2"
global.namaCreator = "Fadel Dev"
global.autoJoin = false
global.antilink = false
global.versisc = "2.0.0"
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = "-" // domain
global.apikey = "-"
global.capikey = "-"
global.domain2 = "-"
global.apikey2 = "-"
global.capikey2 = "-"
global.domain3 = "-"
global.apikey3 = "-"
global.capikey3 = "-"
global.eggsnya = "15"
global.location = "1"
global.imageurl = "https://img101.pixhost.to/images/100/546827117_than.jpg"
global.isLink = false
global.audionya = fs.readFileSync("./all/sound.mp3")
global.simbol = "ダ"
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = "Fadel Dev" //GANTI AJ
global.author = "Fadel Dev"
global.jumlah = "5"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Bung, Ada Yang Berubah Di ${__filename}`))
	delete require.cache[file]
	require(file)
})